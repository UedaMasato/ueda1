detectron2.config
=========================

Related tutorials: :doc:`../tutorials/configs`, :doc:`../tutorials/extend`.

.. automodule:: detectron2.config
    :members:
    :undoc-members:
    :show-inheritance:


Yaml Config References
-----------------

.. literalinclude:: ../../detectron2/config/defaults.py
  :language: python
  :linenos:
  :lines: 7-
